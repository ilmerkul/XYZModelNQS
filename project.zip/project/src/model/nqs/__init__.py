from .nqs import Model
from .operators import get_model_netket_op, get_spin_operators
